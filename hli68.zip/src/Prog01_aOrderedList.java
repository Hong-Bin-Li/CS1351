//Hong Bin Li
//896235238
//2
import java.io.PrintWriter;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;



public class Prog01_aOrderedList {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        aOrderedList carList = new aOrderedList();
        try {
            Scanner inputFile = GetInputFile("Enter input filename: ");
            while (inputFile.hasNextLine()) {
                String line = inputFile.nextLine();
                String[] parts = line.split(",");

                if (parts[0].equals("A")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);

                    Car newCar = new Car(make, year, price);
                    carList.add(newCar);
                } else {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = 0;
                    Car deleteCar = new Car(make, year, price);
                    carList.deleteCar((deleteCar));
                }
            }
            inputFile.close();
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
            e.printStackTrace();
        }


        try {
            PrintWriter out = GetOutputFile("Enter output filename: ");
            out.write(carList.toString());
            out.close();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        in.close();
    }


    public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
        PrintWriter outputFile = null;
        while (true) {
            System.out.println(UserPrompt);
            Scanner input = new Scanner(System.in);
            String filename = input.nextLine();
            try {
                outputFile = new PrintWriter(filename);
                break;
            } catch (FileNotFoundException e) {
                System.out.println("The value entered is incorrect. Please try again or type 'exit' to cancel program execution.");
                String response = input.nextLine();
                if (response.equalsIgnoreCase("exit")) {
                    throw new FileNotFoundException("User requested to cancel program execution.");
                }
            }
        }
        return outputFile;
    }

    public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
        Scanner in = new Scanner(System.in);
        Scanner userInput = in;
        Scanner inputFileScanner = null;
        String inputFileName;
        while (true) {
            System.out.print(UserPrompt);
            inputFileName = userInput.nextLine();
            File inputFile = new File(inputFileName);
            if (inputFile.exists()) {
                inputFileScanner = new Scanner(inputFile);
                break;
            } else {
                System.out.println("File specified <" + inputFileName + "> does not exist. Would you like to continue? <Y/N> ");
                String continueChoice = userInput.nextLine();
                if (continueChoice.equalsIgnoreCase("N")) {
                    throw new FileNotFoundException("User cancelled the operation.");
                }
            }
        }
        return inputFileScanner;
    }

    static class Car {
        private String make;
        private int year;
        private int price;

        public Car(String Make, int Year, int Price) {
            make = Make;
            year = Year;
            price = Price;
        }

        public String getMake() {
            return make;
        }

        public int getYear() {
            return year;
        }

        public int getPrice() {
            return price;
        }

        public int compareTo(Car other) {
            int carCompare = this.make.compareTo(other.make);

            if (carCompare != 0) {
                return carCompare;
            }

            return Integer.compare(this.year, other.year);
        }

        public String toString() {
            return "“Make: “ + make + “, Year : “ + year + “, Price: “ + price + “;”";
        }
    }

    static class aOrderedList {
        private final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
        private Car[] oList; //the ordered list
        private int listSize; //the size of the ordered list
        private int numObjects; //the number of objects in the ordered list


        public aOrderedList() {
            numObjects = 0;
            listSize = SIZEINCREMENTS;
            oList = new Car[listSize];
        }

        public void add(Car newCar) {
            if (numObjects == listSize) {
                listSize += SIZEINCREMENTS;
                Car[] newOList = new Car[listSize];
                System.arraycopy(oList, 0, newOList, 0, numObjects);
                oList = newOList;
            }
            int i;
            for (i = numObjects - 1; i >= 0; i--) {
                if (newCar.compareTo(oList[i]) > 0) {
                    break;
                }
                oList[i + 1] = oList[i];
            }
            oList[i + 1] = newCar;
            numObjects++;
        }


        public void deleteCar(Car deleteCar) {
            int indexToDelete = -1;

            for (int i = 0; i < numObjects; i++) {
                if (oList[i].getMake().equals(deleteCar.getMake()) && oList[i].getYear() == (deleteCar.getYear())) {
                    indexToDelete = i;
                    break;
                }

            }
            if (indexToDelete != -1) {
                for (int i = indexToDelete; i < numObjects - 1; i++) {
                    oList[i] = oList[i + 1];
                }
                numObjects--;

                if (listSize > SIZEINCREMENTS && numObjects < listSize - SIZEINCREMENTS) {
                    listSize -= SIZEINCREMENTS;
                    Car[] newList = new Car[listSize];
                    System.arraycopy(oList, 0, newList, 0, numObjects);
                    oList = newList;
                }
            }
        }


        @Override
        public String toString() {

            StringBuilder sb = new StringBuilder();
            sb.append("Number of cars: \t" + numObjects + "\n\n");
            for (int i = 0; i < numObjects; i++) {
                Car a = oList[i];
                sb.append("Make: \t" + a.getMake() + "\n");
                sb.append("Year: \t" + a.getYear() + "\n");
                sb.append("Price: \t$" + a.getPrice() + "\n\n");
            }
            return sb.toString();
        }

        public int size() {
            return numObjects;
        }

        public Car get(int index) {
            return oList[index];
        }

        public boolean isEmpty() {
            return numObjects == 0;
        }

        public void remove(int index) {
        }
    }
}



